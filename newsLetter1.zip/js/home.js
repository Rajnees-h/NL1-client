import { getRoot} from './jsHelper'

getRoot();