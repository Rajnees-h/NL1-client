
import { FetchAllNews } from './index.js';

// Server Url
const serverUrl = 'https://my-news-letter-h5vk.onrender.com/';

renderAllNews();
console.log('Add news started');
const addNewsButton = document.getElementById('addNews');
const cancelModalButton = document.getElementById('cancelModal');
const closeModalCrossButton = document.getElementById('closeModalCrossButton');
const submitModalButton = document.getElementById('submitNewsDetail')
console.log(addNewsButton);

addNewsButton.onclick = function(){
    openModal();
}
cancelModalButton.onclick = function(){
    closeModal();
}
closeModalCrossButton.onclick = function(){
    closeModal();
}

submitModalButton.onclick = function(){
    storeNews();
}
console.log('Add news completed');


// JavaScript to handle modal functionality
var modal = document.getElementById('myModal');

function openModal() {
  modal.style.display = 'block';
}

function closeModal() {
  modal.style.display = 'none';
}

// Close the modal if the user clicks outside of it
window.onclick = function(event) {
  if (event.target == modal) {
    closeModal();
  }
}


// Add your storeNews() function implementation here
function storeNews() {

    console.log('Store news called');
    var news = {}

     news.heading = document.getElementById('heading').value;
     news.subHeading = document.getElementById('subHeading').value;
     news.detailNews = document.getElementById('detailNews').value;
     news.author = document.getElementById('author').value;
     news.publicationData = document.getElementById('publicationDate').value;
     news.imageUrl = document.getElementById('imageUrl').value;
     news.videoUrl = document.getElementById('videoUrl').value;
     news.isHot = false;//document.getElementById('isHot').value;

     console.log('Store news fetched all data');
     console.log(news);



    //  const news = 
    //  {
    //    "heading": "Hydroponics Revolution: Growing Food Without Soil",
    //    "subHeading": "Vertical farming takes root with sustainable water-based systems",
    //    "detailNews": "The future of agriculture is taking root in urban vertical farms, where leafy greens and herbs flourish without a single grain of soil. Hydroponics, the science of growing plants in nutrient-rich water solutions, is revolutionizing farming by minimizing water usage, reducing environmental impact, and increasing yields. Imagine rows of vibrant lettuce stacked high in a city center, bathed in controlled LED lighting and meticulously fed through precisely monitored water systems. This innovative approach not only offers a viable solution for food security in densely populated areas but also significantly reduces the carbon footprint associated with traditional farming methods.",
    //    "author": "Dr. Sarah Jones",
    //    "publicationDate": "2023-12-26",
    //    "imageUrl": "images/news1.jpg",
    //    "videoUrl": "https://www.w3schools.com/html/mov_bbb.mp4",
    //    "isHotNews": true
    //  };


     try{
        insertNewsInDatabase(news);
     }catch{
        console.log('Failed to Insert data in database');
        alert('Failed to Insert');
     }

     alert('Successfully Added');

  closeModal(); // Close the modal after submission
}




async function renderAllNews(){
   
    const container = document.getElementById('render-all-news');
    var all_news = await FetchAllNews();
    all_news.forEach(news => {
        container.appendChild(createNewsPanel(news));
    });
    console.log('All news Fetched');
    console.log(all_news);
}


function createNewsPanel(news) {
    // Create elements
    var panel = document.createElement('div');
    panel.className = 'panel panel-default';

    var panelHeading = document.createElement('div');
    panelHeading.className = 'panel-heading';

    var headingTitle = document.createElement('h4');
    headingTitle.className = 'panel-title';

    var anchor = document.createElement('a');
    anchor.setAttribute('data-toggle', 'collapse');
    anchor.setAttribute('data-parent', '#newsList');
    anchor.setAttribute('href', '#'+news._id+'');
    anchor.textContent = news.heading;

    headingTitle.appendChild(anchor);
    panelHeading.appendChild(headingTitle);

    var panelCollapse = document.createElement('div');
    panelCollapse.id = news._id;
    panelCollapse.className = 'panel-collapse collapse';

    var panelBody = document.createElement('div');
    panelBody.className = 'panel-body';

    var appDiv = document.createElement('div');
    appDiv.id = 'app';

    var mediaContainer = document.createElement('div');
    mediaContainer.className = 'media-container';

    var image = document.createElement('img');
    image.src = 'path/to/news/image.jpg';
    image.alt = 'News Image';

    var video = document.createElement('video');
    video.controls = true;
    video.textContent = 'Your browser does not support the video tag.';
    
    var videoSource = document.createElement('source');
    videoSource.src = 'path/to/news/video.mp4';
    videoSource.type = 'video/mp4';

    video.appendChild(videoSource);
    mediaContainer.appendChild(image);
    mediaContainer.appendChild(video);
    appDiv.appendChild(mediaContainer);

    var h5 = document.createElement('h5');
    var publisherDetails = document.createElement('span');
    publisherDetails.id = 'publisher-details';
    publisherDetails.className = 'glyphicon glyphicon-time';
    h5.appendChild(publisherDetails);
    h5.innerHTML += 'Post by Author Name, Sep 27, 2015.';

    var subHeading = document.createElement('h3');
    subHeading.id = 'sub-heading';
    subHeading.textContent = 'News Subheading';

    var newsDetail = document.createElement('p');
    newsDetail.id = 'news-detail';
    newsDetail.textContent = 'Details of the news go here.';

    appDiv.appendChild(h5);
    appDiv.appendChild(subHeading);
    appDiv.appendChild(newsDetail);

    panelBody.appendChild(appDiv);
    panelCollapse.appendChild(panelBody);

    panel.appendChild(panelHeading);
    panel.appendChild(panelCollapse);

    return panel;
  }

    

// function storeNews() {
//   const newsData = {
//     heading: document.getElementById('heading').value,
//     subHeading: document.getElementById('subHeading').value,
//     detailNews: document.getElementById('detailNews').value,
//     author: document.getElementById('author').value,
//     publicationDate: document.getElementById('publicationDate').value,
//     imageUrl: document.getElementById('imageUrl').value,
//     videoUrl: document.getElementById('videoUrl').value,
//     isHotNews: document.getElementById('isHotNews').checked
//   };

// const news = 
//   {
//     "heading": "Hydroponics Revolution: Growing Food Without Soil",
//     "subHeading": "Vertical farming takes root with sustainable water-based systems",
//     "detailNews": "The future of agriculture is taking root in urban vertical farms, where leafy greens and herbs flourish without a single grain of soil. Hydroponics, the science of growing plants in nutrient-rich water solutions, is revolutionizing farming by minimizing water usage, reducing environmental impact, and increasing yields. Imagine rows of vibrant lettuce stacked high in a city center, bathed in controlled LED lighting and meticulously fed through precisely monitored water systems. This innovative approach not only offers a viable solution for food security in densely populated areas but also significantly reduces the carbon footprint associated with traditional farming methods.",
//     "author": "Dr. Sarah Jones",
//     "publicationDate": "2023-12-26",
//     "imageUrl": "images/news1.jpg",
//     "videoUrl": "https://youtu.be/AUnPAw-oQdQ?si=t0lUEm-PQumrGxl8",
//     "isHotNews": true
//   };
//   {
//     "heading": "Drones Patrol the Fields: Precision Agriculture Takes Flight",
//     "subHeading": "Unmanned aerial vehicles monitor crops and optimize resource usage",
//     "detailNews": "Imagine tiny, buzzing eyes scanning vast fields of golden wheat, meticulously collecting data on plant health, water distribution, and pest infestations. This futuristic vision is becoming a reality thanks to the integration of drones into modern agriculture. Equipped with high-resolution cameras and advanced sensors, these unmanned aerial vehicles provide farmers with real-time insights into their crops, allowing them to make precise decisions about irrigation, fertilization, and pest control. By pinpointing problem areas and applying resources only where needed, drones offer the potential to increase yields, reduce waste, and ultimately, create a more sustainable agricultural system.",
//     "author": "Max Thompson",
//     "publicationDate": "2023-12-25",
//     "imageUrl": "images/news2.jpeg",
//     "videoUrl": "https://youtu.be/AUnPAw-oQdQ?si=t0lUEm-PQumrGxl8",
//     "isHotNews": false
//   },
//   {
//     "heading": "CRISPR Editing for Superfoods: Engineering Crops for Enhanced Nutrition",
//     "subHeading": "Gene editing technology promises healthier, more resilient plants",
//     "detailNews": "The power of genetic engineering is being harnessed to create the next generation of superfoods. CRISPR, a revolutionary gene-editing tool, allows scientists to precisely modify plant DNA, potentially enhancing their nutritional content, resistance to disease, and tolerance to harsh environmental conditions. Imagine rice enriched with vitamin A, tomatoes with extended shelf life, or bananas naturally fortified with iron. These possibilities, once relegated to the realm of science fiction, are inching closer to reality thanks to CRISPR technology. While ethical considerations remain important, the potential benefits of CRISPR-edited crops for global food security and nutrition are undeniable.",
//     "author": "Dr. Alexia Lee",
//     "publicationDate": "2023-12-24",
//     "imageUrl": "images/news1.jpg",
//     "videoUrl": "https://youtu.be/AUnPAw-oQdQ?si=t0lUEm-PQumrGxl8",
//     "isHotNews": true
//   }
// ]


//   // You can perform further actions with the newsData, such as sending it to a server or storing it locally.
// insertNewsInDatabase(news)

//   alert('Successfully Added');

// }


function insertNewsInDatabase(news){
fetch(serverUrl+"create", {
method: "POST",
headers: {
"Content-Type": "application/json",
},
body: JSON.stringify(news),
})
.then((response) => response.json())
.then((data) => {
console.log(data);
const createdData = data;
console.log(data);
})
.catch((error) => console.error("Error in creating News:", error));
}

